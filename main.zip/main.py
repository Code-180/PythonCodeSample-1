#++++++++++++++++++++++++++++++++++++++++
from PIL import Image
from PIL.ExifTags import TAGS
#++++++++++++++++++++++++++++++++++++++++
#Call The Image
#++++++++++++++++++++++++++++++++++++++++
image = Image.open("1.jpg")
#++++++++++++++++++++++++++++++++++++++++
exifdata = image.getexif()
#++++++++++++++++++++++++++++++++++++++++
for tagid in exifdata:
	main_tags = TAGS.get(tagid, tagid)
	data = exifdata.get(tagid)
	print(f"{main_tags:25}: {data}")

